# Notes techniques – Prototype UTP

## Composants

- `MainActivity.java` : écrans et parcours utilisateur
- `CourseRepository.java` : lecture du JSON de cours
- `AudioRecorder.java` : enregistrement PCM 16 kHz mono + WAV de réécoute
- `ModelAudioPlayer.java` : audio UTP personnalisé ou TTS `en-US`
- `SpeechEvaluationEngine.java` : reconnaissance et scores
- `Similarity.java` : comparaison avec plusieurs réponses acceptables
- `ProgressStore.java` : progression locale

## Reconnaissance vocale

Le prototype s'appuie sur `android.speech.SpeechRecognizer`.

- API 31+ : utilise le moteur on-device si Android indique qu'il est disponible.
- API 33+ : tente l'analyse du PCM déjà enregistré via `RecognizerIntent.EXTRA_AUDIO_SOURCE`.
- Le flag `EXTRA_PREFER_OFFLINE` est demandé.
- Les implémentations Android peuvent ignorer certaines options ; l'application ne prétend donc pas garantir l'offline sur tous les téléphones.

## Réponses multiples

Le moteur ne compare pas seulement avec une phrase unique.

Pour chaque transcription retournée par Android :

1. comparaison mot par mot avec chaque réponse acceptable ;
2. couverture des mots importants ;
3. sélection de la meilleure réponse acceptable ;
4. sélection de la meilleure hypothèse de transcription.

Cela permet par exemple d'accepter :

- I'm good.
- I'm fine.
- I'm great.
- I'm doing well, thanks.

## Limite de l'analyse du sens

Le prototype ne contient pas de modèle LLM ni de serveur sémantique. Il couvre donc le sens via :

- listes de réponses naturelles acceptables ;
- réponses ouvertes pour les questions libres ;
- mots importants.

Pour un futur moteur sémantique avancé, ajouter une couche séparée afin de préserver la logique de cours locale.

## Pronunciation

Le score Pronunciation est volontairement présenté comme **estimation prototype**. `SpeechRecognizer` ne fournit pas une note phonémique complète. Une note phonème-par-phonème exige un moteur de pronunciation assessment spécialisé.

## Confidentialité prototype

- Aucun compte.
- Aucun serveur UTP.
- Progression en `SharedPreferences`.
- Audio utilisateur enregistré dans le cache de l'application et réutilisé pour l'évaluation.
- Si le téléphone ne dispose pas d'un moteur de reconnaissance on-device, le fournisseur de reconnaissance système peut envoyer la voix à son service réseau. Cela dépend du téléphone/moteur installé.
