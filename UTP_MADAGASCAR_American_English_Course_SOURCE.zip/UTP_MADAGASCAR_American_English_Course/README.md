# UTP MADAGASCAR – American English Course

**Tagline:** Speak • Listen • Practice • Improve

Prototype Android natif pour UTP Madagascar.

## Prototype inclus

- HOME avec le logo officiel UTP fourni par l'utilisateur
- LEVEL 1 – GREETINGS
- 5 dialogues pratiques
- LISTEN / REPLAY en voix `en-US` via Android TextToSpeech
- RECORD réel au microphone (PCM 16 kHz + copie WAV pour réécoute)
- PLAY MY ANSWER
- EVALUATE avec Android SpeechRecognizer
- plusieurs réponses acceptables par question
- score Pronunciation (estimation prototype), Word Accuracy, Fluency, Speaking, Overall
- feedback automatique
- Conversation Mode
- Final Greetings Speaking Test
- My Progress enregistré localement
- Vocabulary
- American Fast Speech : Slow / Normal / Fast
- mini-section American Pronunciation pour Greetings
- 20 topics déjà déclarés dans la structure de contenu, seul Greetings est activé

## Logo officiel

Le fichier fourni a été copié tel quel dans :

`app/src/main/res/drawable/utp_logo.jpg`

Aucune nouvelle identité visuelle ni nouveau logo n'a été généré.
SHA-256 de la copie intégrée :
`150f449080ee632da61890dab17f34a3b54cb655ba69b81990ce2ac53dccb7a2`

## Architecture

L'application sépare la logique et le contenu :

- **Logique Android :** `app/src/main/java/com/utpmadagascar/americanenglish/`
- **Contenu du cours :** `app/src/main/assets/course_content.json`
- **Audios personnalisés :** `app/src/main/assets/audio/`
- **Logo :** `app/src/main/res/drawable/utp_logo.jpg`

Le contenu peut donc être enrichi sans réécrire le moteur principal.

## Évaluation vocale : limitation importante

Le prototype utilise les APIs Android réellement disponibles :

1. L'étudiant enregistre son audio localement.
2. Sur Android 13+ (API 33+), l'application tente d'envoyer le PCM enregistré au `SpeechRecognizer` avec `EXTRA_AUDIO_SOURCE`.
3. Si un moteur de reconnaissance **on-device** est installé, l'application le privilégie.
4. Sinon, le moteur système peut utiliser Internet selon le téléphone et le fournisseur de reconnaissance.
5. Si le moteur installé ne supporte pas l'analyse d'un fichier audio injecté, l'application bascule vers une reconnaissance micro et demande de redire la réponse.

### Ce que signifie le score Pronunciation du prototype

Ce n'est **pas** une analyse phonème-par-phonème comparable à un moteur spécialisé payant. Le score est une estimation calculée à partir de :

- confiance du SpeechRecognizer lorsqu'elle est disponible ;
- correspondance avec les réponses acceptables ;
- qualité de reconnaissance globale.

Le score Word Accuracy repose sur la meilleure correspondance parmi plusieurs réponses acceptables. Le score Fluency est estimé à partir de la durée et du nombre de mots reconnus.

Pour une future version avec notation phonémique réelle, il faudra intégrer un moteur dédié (API cloud ou modèle embarqué spécialisé).

## Audio modèle

Par défaut le prototype utilise Android TextToSpeech en locale `en-US`.

Pour garantir une voix américaine identique sur tous les téléphones, il est préférable d'ajouter plus tard les fichiers MP3/WAV UTP enregistrés par un locuteur américain dans `assets/audio/`, puis de renseigner `audioAsset` dans le JSON.

## Fichiers utiles

- `BUILD_APK.md` : compilation et installation
- `GUIDE_CONTENU.md` : ajouter topics, dialogues, réponses, audios et niveaux
- `TECHNICAL_NOTES.md` : logique des scores et reconnaissance vocale
