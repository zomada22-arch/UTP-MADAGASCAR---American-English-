package com.utpmadagascar.americanenglish;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import org.json.JSONArray;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public final class SpeechEvaluationEngine {
    private final Context context;
    private SpeechRecognizer recognizer;
    private ParcelFileDescriptor audioFd;
    private boolean usingInjectedAudio;
    private boolean fallbackAttempted;
    private EvalRequest current;

    public SpeechEvaluationEngine(Context context) {
        this.context = context;
    }

    public boolean hasRecognitionService() {
        return SpeechRecognizer.isRecognitionAvailable(context);
    }

    public boolean hasOnDeviceRecognition() {
        return Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context);
    }

    public String recognitionModeLabel() {
        if (hasOnDeviceRecognition()) return "On-device speech recognition available (offline capable)";
        return "System speech recognition (may require Internet on this device)";
    }

    public void evaluate(AudioRecorder.Recording recording, JSONArray acceptedAnswers,
                         boolean openResponse, int minWords, Callback callback) {
        if (recording == null || recording.pcmFile == null || !recording.pcmFile.exists()) {
            callback.onError("Record an answer first.");
            return;
        }
        current = new EvalRequest(recording, acceptedAnswers, openResponse, minWords, callback);
        fallbackAttempted = false;
        if (Build.VERSION.SDK_INT >= 33) {
            startRecognition(true);
        } else {
            callback.onStatus("This Android version cannot send the saved recording to SpeechRecognizer. Say the answer once more for evaluation.");
            startRecognition(false);
        }
    }

    private void startRecognition(boolean injectAudio) {
        cleanupRecognizer();
        usingInjectedAudio = injectAudio;
        try {
            recognizer = createRecognizer();
        } catch (Exception e) {
            current.callback.onError("Speech recognition is not available: " + e.getMessage());
            return;
        }
        recognizer.setRecognitionListener(listener);

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag());
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        if (Build.VERSION.SDK_INT >= 23) intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);

        if (Build.VERSION.SDK_INT >= 33 && injectAudio) {
            try {
                audioFd = ParcelFileDescriptor.open(current.recording.pcmFile, ParcelFileDescriptor.MODE_READ_ONLY);
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, audioFd);
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, AudioRecorder.CHANNELS);
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT);
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, AudioRecorder.SAMPLE_RATE);
                ArrayList<String> bias = new ArrayList<>();
                for (int i = 0; i < current.acceptedAnswers.length(); i++) {
                    String s = current.acceptedAnswers.optString(i, "");
                    if (!s.isEmpty()) bias.add(s);
                }
                if (!bias.isEmpty()) intent.putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, bias);
            } catch (IOException e) {
                current.callback.onError("Could not open the saved recording for evaluation.");
                cleanupRecognizer();
                return;
            }
            current.callback.onStatus("Analyzing your saved answer… " + recognitionModeLabel());
        } else {
            current.callback.onStatus("Speak now for evaluation… " + recognitionModeLabel());
        }
        recognizer.startListening(intent);
    }

    private SpeechRecognizer createRecognizer() {
        if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
            return SpeechRecognizer.createOnDeviceSpeechRecognizer(context);
        }
        return SpeechRecognizer.createSpeechRecognizer(context);
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rmsdB) {}
        @Override public void onBufferReceived(byte[] buffer) {}
        @Override public void onEndOfSpeech() {}

        @Override public void onError(int error) {
            String message = errorMessage(error);
            boolean canFallback = usingInjectedAudio && !fallbackAttempted &&
                    (error == SpeechRecognizer.ERROR_AUDIO || error == SpeechRecognizer.ERROR_CLIENT ||
                     error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SERVER);
            closeFd();
            if (canFallback) {
                fallbackAttempted = true;
                current.callback.onStatus("Saved-audio analysis is not supported by this recognizer. Please say the answer once more now.");
                startRecognition(false);
                return;
            }
            cleanupRecognizer();
            current.callback.onError(message);
        }

        @Override public void onResults(Bundle results) {
            ArrayList<String> texts = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            float[] confidences = results.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);
            if (texts == null || texts.isEmpty()) {
                current.callback.onError("No speech was recognized. Try again.");
                cleanupRecognizer();
                return;
            }

            String bestText = texts.get(0);
            double bestSemantic = -1;
            int bestIndex = 0;
            String matched = "";
            for (int i = 0; i < texts.size(); i++) {
                String t = texts.get(i);
                double score;
                String localMatch = "";
                if (current.openResponse) {
                    int wc = Similarity.tokens(t).size();
                    score = wc >= current.minWords ? 1.0 : (current.minWords == 0 ? 1.0 : (double) wc / current.minWords);
                } else {
                    Similarity.Match m = Similarity.bestMatch(t, current.acceptedAnswers);
                    score = m.score;
                    localMatch = m.answer;
                }
                if (score > bestSemantic) {
                    bestSemantic = score;
                    bestText = t;
                    bestIndex = i;
                    matched = localMatch;
                }
            }

            double conf = -1;
            if (confidences != null && bestIndex < confidences.length && confidences[bestIndex] >= 0) {
                conf = confidences[bestIndex];
            }
            SpeechScore score = calculate(bestText, matched, bestSemantic, conf,
                    current.recording.durationSeconds, current.openResponse, current.minWords);
            closeFd();
            cleanupRecognizer();
            current.callback.onSuccess(score);
        }

        @Override public void onPartialResults(Bundle partialResults) {}
        @Override public void onEvent(int eventType, Bundle params) {}
    };

    private SpeechScore calculate(String transcript, String matched, double semantic,
                                  double confidence, double duration, boolean open, int minWords) {
        int wordAccuracy;
        if (open) {
            int words = Similarity.tokens(transcript).size();
            wordAccuracy = words >= minWords ? 100 : clamp((int) Math.round(100.0 * words / Math.max(1, minWords)));
        } else {
            wordAccuracy = clamp((int) Math.round(semantic * 100));
        }

        int recognitionConfidence = confidence >= 0 ? clamp((int) Math.round(confidence * 100)) : wordAccuracy;
        int pronunciation = clamp((int) Math.round(recognitionConfidence * 0.60 + wordAccuracy * 0.40));

        int wordCount = Math.max(1, Similarity.tokens(transcript).size());
        double idealSeconds = Math.max(1.3, wordCount / 2.2); // ~132 words/minute
        double ratio = duration <= 0.2 ? 3.0 : duration / idealSeconds;
        int fluency;
        if (ratio >= 0.70 && ratio <= 1.65) fluency = 92;
        else if (ratio < 0.70) fluency = clamp((int) Math.round(92 - (0.70 - ratio) * 90));
        else fluency = clamp((int) Math.round(92 - (ratio - 1.65) * 28));
        fluency = clamp((int) Math.round(fluency * 0.75 + wordAccuracy * 0.25));

        int speaking = clamp((int) Math.round(pronunciation * 0.35 + wordAccuracy * 0.35 + fluency * 0.30));
        int overall = clamp((int) Math.round(pronunciation * 0.30 + wordAccuracy * 0.30 + fluency * 0.20 + speaking * 0.20));

        String feedback;
        if (overall >= 90) feedback = "Excellent! Keep practicing.";
        else if (overall >= 82) feedback = "Good pronunciation. Keep your rhythm natural.";
        else if (overall >= 72) feedback = "Good job! Try to speak more naturally.";
        else if (overall >= 60) feedback = "Some words need more practice. Try again.";
        else feedback = "Work more on your pronunciation and key words, then try again.";

        return new SpeechScore(pronunciation, wordAccuracy, fluency, speaking, overall,
                transcript, matched, feedback);
    }

    private int clamp(int v) { return Math.max(0, Math.min(100, v)); }

    private String errorMessage(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "Audio recognition error. Try again.";
            case SpeechRecognizer.ERROR_CLIENT: return "Speech recognizer could not process this recording.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Microphone permission is required.";
            case SpeechRecognizer.ERROR_NETWORK: return "The installed speech recognizer needs a network connection.";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Speech recognition network timeout.";
            case SpeechRecognizer.ERROR_NO_MATCH: return "No clear match was recognized. Try again slowly and clearly.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Speech recognizer is busy. Try again.";
            case SpeechRecognizer.ERROR_SERVER: return "Speech recognition service error.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "No speech detected. Try again.";
            default: return "Speech recognition error (" + error + ").";
        }
    }

    private void closeFd() {
        if (audioFd != null) {
            try { audioFd.close(); } catch (IOException ignored) {}
            audioFd = null;
        }
    }

    private void cleanupRecognizer() {
        closeFd();
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
            recognizer.destroy();
            recognizer = null;
        }
    }

    public void release() { cleanupRecognizer(); }

    private static final class EvalRequest {
        final AudioRecorder.Recording recording;
        final JSONArray acceptedAnswers;
        final boolean openResponse;
        final int minWords;
        final Callback callback;
        EvalRequest(AudioRecorder.Recording recording, JSONArray acceptedAnswers,
                    boolean openResponse, int minWords, Callback callback) {
            this.recording = recording;
            this.acceptedAnswers = acceptedAnswers == null ? new JSONArray() : acceptedAnswers;
            this.openResponse = openResponse;
            this.minWords = minWords;
            this.callback = callback;
        }
    }

    public interface Callback {
        void onStatus(String text);
        void onSuccess(SpeechScore score);
        void onError(String message);
    }
}
