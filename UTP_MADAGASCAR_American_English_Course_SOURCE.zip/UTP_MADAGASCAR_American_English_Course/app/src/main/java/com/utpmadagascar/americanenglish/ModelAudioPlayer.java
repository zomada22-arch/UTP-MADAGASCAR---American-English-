package com.utpmadagascar.americanenglish;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.speech.tts.TextToSpeech;

import java.io.IOException;
import java.util.Locale;

public final class ModelAudioPlayer {
    private final Context context;
    private TextToSpeech tts;
    private boolean ready;
    private MediaPlayer mediaPlayer;

    public ModelAudioPlayer(Context context) {
        this.context = context.getApplicationContext();
        tts = new TextToSpeech(this.context, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.US);
                ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setPitch(1.0f);
                tts.setSpeechRate(0.92f);
            }
        });
    }

    public boolean isReady() { return ready; }

    public void play(String text, String audioAsset, float rate) throws IOException {
        stop();
        if (audioAsset != null && !audioAsset.trim().isEmpty()) {
            AssetFileDescriptor afd = context.getAssets().openFd("audio/" + audioAsset);
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mediaPlayer.prepare();
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(rate));
            }
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(mp -> stop());
            return;
        }
        if (!ready) throw new IOException("American English TTS voice is not ready on this device.");
        tts.setSpeechRate(rate);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utp-model");
    }

    public void stop() {
        if (tts != null) tts.stop();
        if (mediaPlayer != null) {
            try { mediaPlayer.stop(); } catch (Exception ignored) {}
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    public void release() {
        stop();
        if (tts != null) {
            tts.shutdown();
            tts = null;
        }
    }
}
