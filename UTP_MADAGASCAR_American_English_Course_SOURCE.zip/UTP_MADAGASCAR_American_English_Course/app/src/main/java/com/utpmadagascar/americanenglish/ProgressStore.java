package com.utpmadagascar.americanenglish;

import android.content.Context;
import android.content.SharedPreferences;

public final class ProgressStore {
    private static final String PREF = "utp_progress";
    private final SharedPreferences p;

    public ProgressStore(Context context) {
        p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void recordListen() {
        p.edit().putInt("listen_count", p.getInt("listen_count", 0) + 1).apply();
    }

    public void recordPractice(SpeechScore s) {
        int n = p.getInt("practice_count", 0) + 1;
        p.edit()
                .putInt("practice_count", n)
                .putInt("sum_pronunciation", p.getInt("sum_pronunciation", 0) + s.pronunciation)
                .putInt("sum_word", p.getInt("sum_word", 0) + s.wordAccuracy)
                .putInt("sum_fluency", p.getInt("sum_fluency", 0) + s.fluency)
                .putInt("sum_speaking", p.getInt("sum_speaking", 0) + s.speaking)
                .putInt("sum_overall", p.getInt("sum_overall", 0) + s.overall)
                .apply();
    }

    public void markDialogueCompleted(String topicId, String dialogueId) {
        p.edit().putBoolean("dialogue_" + topicId + "_" + dialogueId, true).apply();
    }

    public boolean isDialogueCompleted(String topicId, String dialogueId) {
        return p.getBoolean("dialogue_" + topicId + "_" + dialogueId, false);
    }

    public void markTestCompleted(String topicId, int score) {
        p.edit().putBoolean("test_" + topicId + "_done", true)
                .putInt("test_" + topicId + "_score", score).apply();
    }

    public boolean testDone(String topicId) {
        return p.getBoolean("test_" + topicId + "_done", false);
    }

    public int testScore(String topicId) {
        return p.getInt("test_" + topicId + "_score", 0);
    }

    public int practiceCount() { return p.getInt("practice_count", 0); }
    public int listenCount() { return p.getInt("listen_count", 0); }

    private int avg(String key) {
        int n = practiceCount();
        return n == 0 ? 0 : Math.round((float) p.getInt(key, 0) / n);
    }

    public int avgPronunciation() { return avg("sum_pronunciation"); }
    public int avgWord() { return avg("sum_word"); }
    public int avgFluency() { return avg("sum_fluency"); }
    public int avgSpeaking() { return avg("sum_speaking"); }
    public int avgOverall() { return avg("sum_overall"); }

    public int listeningScore() {
        int c = Math.min(5, listenCount());
        return Math.round(c * 100f / 5f);
    }

    public void reset() {
        p.edit().clear().apply();
    }
}
