package com.utpmadagascar.americanenglish;

public final class SpeechScore {
    public final int pronunciation;
    public final int wordAccuracy;
    public final int fluency;
    public final int speaking;
    public final int overall;
    public final String transcript;
    public final String matchedAnswer;
    public final String feedback;

    public SpeechScore(int pronunciation, int wordAccuracy, int fluency, int speaking,
                       int overall, String transcript, String matchedAnswer, String feedback) {
        this.pronunciation = pronunciation;
        this.wordAccuracy = wordAccuracy;
        this.fluency = fluency;
        this.speaking = speaking;
        this.overall = overall;
        this.transcript = transcript;
        this.matchedAnswer = matchedAnswer;
        this.feedback = feedback;
    }
}
