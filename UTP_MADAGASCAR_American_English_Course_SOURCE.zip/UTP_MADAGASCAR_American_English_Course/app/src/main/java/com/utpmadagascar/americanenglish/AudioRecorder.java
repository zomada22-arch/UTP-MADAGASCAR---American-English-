package com.utpmadagascar.americanenglish;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.media.MediaRecorder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public final class AudioRecorder {
    public static final int SAMPLE_RATE = 16000;
    public static final int CHANNELS = 1;
    public static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

    private AudioRecord audioRecord;
    private Thread worker;
    private volatile boolean recording;
    private File pcmFile;
    private File wavFile;
    private long pcmBytes;
    private MediaPlayer player;

    public void start(Context context) throws IOException, SecurityException {
        stopPlayback();
        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, ENCODING);
        if (min <= 0) throw new IOException("AudioRecord buffer unavailable");
        int bufferSize = Math.max(min * 2, 4096);
        audioRecord = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, ENCODING, bufferSize);
        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
            audioRecord.release();
            audioRecord = null;
            throw new IOException("Microphone could not be initialized");
        }

        pcmFile = new File(context.getCacheDir(), "utp_last_answer.pcm");
        wavFile = new File(context.getCacheDir(), "utp_last_answer.wav");
        pcmBytes = 0;
        recording = true;
        audioRecord.startRecording();

        worker = new Thread(() -> {
            byte[] buffer = new byte[bufferSize];
            try (FileOutputStream out = new FileOutputStream(pcmFile, false)) {
                while (recording) {
                    int read = audioRecord.read(buffer, 0, buffer.length);
                    if (read > 0) {
                        out.write(buffer, 0, read);
                        pcmBytes += read;
                    }
                }
            } catch (IOException ignored) {
            }
        }, "UTP-AudioRecorder");
        worker.start();
    }

    public Recording stop() throws IOException {
        if (!recording) return currentRecording();
        recording = false;
        if (audioRecord != null) {
            try { audioRecord.stop(); } catch (Exception ignored) {}
        }
        if (worker != null) {
            try { worker.join(1200); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        if (audioRecord != null) {
            audioRecord.release();
            audioRecord = null;
        }
        writeWavFromPcm(pcmFile, wavFile, pcmBytes);
        return currentRecording();
    }

    public boolean isRecording() { return recording; }

    public Recording currentRecording() {
        if (pcmFile == null || !pcmFile.exists() || pcmBytes <= 0) return null;
        double duration = pcmBytes / (double) (SAMPLE_RATE * CHANNELS * 2);
        return new Recording(pcmFile, wavFile, duration);
    }

    public void playLast() throws IOException {
        Recording r = currentRecording();
        if (r == null || !r.wavFile.exists()) throw new IOException("No recording available");
        stopPlayback();
        player = new MediaPlayer();
        player.setDataSource(r.wavFile.getAbsolutePath());
        player.prepare();
        player.start();
        player.setOnCompletionListener(mp -> stopPlayback());
    }

    public void stopPlayback() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
    }

    public void release() {
        if (recording) {
            try { stop(); } catch (Exception ignored) {}
        }
        stopPlayback();
    }

    private static void writeWavFromPcm(File pcm, File wav, long dataLength) throws IOException {
        long byteRate = SAMPLE_RATE * CHANNELS * 16L / 8L;
        try (FileInputStream in = new FileInputStream(pcm);
             FileOutputStream out = new FileOutputStream(wav, false)) {
            byte[] header = new byte[44];
            long totalDataLen = dataLength + 36;
            header[0] = 'R'; header[1] = 'I'; header[2] = 'F'; header[3] = 'F';
            writeIntLE(header, 4, totalDataLen);
            header[8] = 'W'; header[9] = 'A'; header[10] = 'V'; header[11] = 'E';
            header[12] = 'f'; header[13] = 'm'; header[14] = 't'; header[15] = ' ';
            writeIntLE(header, 16, 16);
            writeShortLE(header, 20, 1);
            writeShortLE(header, 22, CHANNELS);
            writeIntLE(header, 24, SAMPLE_RATE);
            writeIntLE(header, 28, byteRate);
            writeShortLE(header, 32, CHANNELS * 16 / 8);
            writeShortLE(header, 34, 16);
            header[36] = 'd'; header[37] = 'a'; header[38] = 't'; header[39] = 'a';
            writeIntLE(header, 40, dataLength);
            out.write(header);
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        }
    }

    private static void writeIntLE(byte[] b, int o, long v) {
        b[o] = (byte) (v & 0xff);
        b[o + 1] = (byte) ((v >> 8) & 0xff);
        b[o + 2] = (byte) ((v >> 16) & 0xff);
        b[o + 3] = (byte) ((v >> 24) & 0xff);
    }

    private static void writeShortLE(byte[] b, int o, int v) {
        b[o] = (byte) (v & 0xff);
        b[o + 1] = (byte) ((v >> 8) & 0xff);
    }

    public static final class Recording {
        public final File pcmFile;
        public final File wavFile;
        public final double durationSeconds;

        Recording(File pcmFile, File wavFile, double durationSeconds) {
            this.pcmFile = pcmFile;
            this.wavFile = wavFile;
            this.durationSeconds = durationSeconds;
        }
    }
}
