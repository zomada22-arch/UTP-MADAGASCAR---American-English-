package com.utpmadagascar.americanenglish;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class Similarity {
    private static final Set<String> STOP = new HashSet<>(Arrays.asList(
            "i", "im", "i'm", "am", "are", "is", "a", "an", "the", "to", "and", "you", "it", "was"
    ));

    private Similarity() {}

    public static String normalize(String s) {
        if (s == null) return "";
        return s.toLowerCase(Locale.US)
                .replace("’", "'")
                .replace("i'm", "im")
                .replace("it's", "its")
                .replace("how's", "hows")
                .replaceAll("[^a-z0-9' ]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    public static List<String> tokens(String s) {
        String n = normalize(s);
        if (n.isEmpty()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(n.split(" ")));
    }

    public static double wordSimilarity(String a, String b) {
        List<String> x = tokens(a);
        List<String> y = tokens(b);
        if (x.isEmpty() && y.isEmpty()) return 1.0;
        int d = editDistance(x, y);
        int max = Math.max(x.size(), y.size());
        return max == 0 ? 1.0 : Math.max(0.0, 1.0 - ((double) d / max));
    }

    private static int editDistance(List<String> a, List<String> b) {
        int[][] dp = new int[a.size() + 1][b.size() + 1];
        for (int i = 0; i <= a.size(); i++) dp[i][0] = i;
        for (int j = 0; j <= b.size(); j++) dp[0][j] = j;
        for (int i = 1; i <= a.size(); i++) {
            for (int j = 1; j <= b.size(); j++) {
                int cost = a.get(i - 1).equals(b.get(j - 1)) ? 0 : 1;
                dp[i][j] = Math.min(
                        Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
                        dp[i - 1][j - 1] + cost
                );
            }
        }
        return dp[a.size()][b.size()];
    }

    public static double keywordCoverage(String spoken, String expected) {
        Set<String> spokenSet = new HashSet<>(tokens(spoken));
        List<String> expectedTokens = tokens(expected);
        int important = 0;
        int found = 0;
        for (String t : expectedTokens) {
            if (STOP.contains(t)) continue;
            important++;
            if (spokenSet.contains(t)) found++;
        }
        if (important == 0) return wordSimilarity(spoken, expected);
        return (double) found / important;
    }

    public static Match bestMatch(String transcript, JSONArray accepted) {
        String best = "";
        double bestScore = 0;
        if (accepted == null) return new Match(best, bestScore);
        for (int i = 0; i < accepted.length(); i++) {
            String candidate = accepted.optString(i, "");
            double word = wordSimilarity(transcript, candidate);
            double keywords = keywordCoverage(transcript, candidate);
            double combined = (word * 0.80) + (keywords * 0.20);
            if (combined > bestScore) {
                bestScore = combined;
                best = candidate;
            }
        }
        return new Match(best, bestScore);
    }

    public static final class Match {
        public final String answer;
        public final double score;
        Match(String answer, double score) {
            this.answer = answer;
            this.score = score;
        }
    }
}
