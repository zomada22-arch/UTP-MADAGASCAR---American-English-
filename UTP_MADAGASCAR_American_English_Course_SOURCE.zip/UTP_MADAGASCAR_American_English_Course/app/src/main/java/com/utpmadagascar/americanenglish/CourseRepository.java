package com.utpmadagascar.americanenglish;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class CourseRepository {
    private final JSONObject root;

    public CourseRepository(Context context) throws IOException, JSONException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                context.getAssets().open("course_content.json"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        root = new JSONObject(sb.toString());
    }

    public JSONArray getLevels() throws JSONException {
        return root.getJSONArray("levels");
    }

    public JSONObject getLevel1() throws JSONException {
        return getLevels().getJSONObject(0);
    }

    public JSONObject getGreetingsTopic() throws JSONException {
        JSONArray topics = getLevel1().getJSONArray("topics");
        for (int i = 0; i < topics.length(); i++) {
            JSONObject topic = topics.getJSONObject(i);
            if ("greetings".equals(topic.optString("id"))) return topic;
        }
        throw new JSONException("Greetings topic not found");
    }

    public JSONArray getTopics() throws JSONException {
        return getLevel1().getJSONArray("topics");
    }
}
