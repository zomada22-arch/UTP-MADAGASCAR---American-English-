package com.utpmadagascar.americanenglish;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 501;
    private static final int NAVY = Color.rgb(7, 26, 61);
    private static final int BLUE = Color.rgb(13, 59, 120);
    private static final int RED = Color.rgb(198, 38, 46);
    private static final int GREEN = Color.rgb(22, 139, 85);
    private static final int BG = Color.rgb(247, 248, 250);
    private static final int TEXT = Color.rgb(16, 24, 40);
    private static final int MUTED = Color.rgb(102, 112, 133);

    private CourseRepository course;
    private JSONObject greetings;
    private JSONObject currentLevel;
    private JSONObject currentTopic;
    private final AudioRecorder recorder = new AudioRecorder();
    private ModelAudioPlayer modelAudio;
    private SpeechEvaluationEngine evaluator;
    private ProgressStore progress;
    private Runnable afterPermissionAction;

    private final ArrayList<SpeechScore> testScores = new ArrayList<>();
    private final ArrayList<SpeechScore> conversationScores = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        try {
            course = new CourseRepository(this);
            greetings = course.getGreetingsTopic();
            currentLevel = course.getLevel1();
            currentTopic = greetings;
        } catch (Exception e) {
            showFatal("Course content could not be loaded: " + e.getMessage());
            return;
        }
        modelAudio = new ModelAudioPlayer(this);
        evaluator = new SpeechEvaluationEngine(this);
        progress = new ProgressStore(this);
        showHome();
    }

    @Override
    protected void onDestroy() {
        recorder.release();
        if (modelAudio != null) modelAudio.release();
        if (evaluator != null) evaluator.release();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        showHome();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (afterPermissionAction != null) afterPermissionAction.run();
            } else {
                toast("Microphone permission is required for speaking practice.");
            }
            afterPermissionAction = null;
        }
    }

    private void showHome() {
        stopTransientAudio();
        LinearLayout root = vertical(NAVY, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.utpmadagascar.americanenglish.R.drawable.utp_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(190), dp(190));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(logo, lp);

        root.addView(spacer(16));
        root.addView(label("UTP MADAGASCAR", 29, Color.WHITE, true, Gravity.CENTER));
        root.addView(label("American English Course", 20, Color.rgb(224, 233, 246), false, Gravity.CENTER));
        root.addView(spacer(8));
        TextView tag = label("Speak • Listen • Practice • Improve", 15, Color.rgb(206, 214, 228), false, Gravity.CENTER);
        tag.setLetterSpacing(0.04f);
        root.addView(tag);
        root.addView(spacer(30));

        root.addView(actionButton("▶  START TRAINING", Color.WHITE, NAVY, v -> showLevels()));
        root.addView(spacer(12));
        root.addView(actionButton("📝  TAKE A TEST", RED, Color.WHITE, v -> { currentTopic = greetings; showFinalTestIntro(); }));
        root.addView(spacer(12));
        root.addView(actionButton("📊  MY PROGRESS", BLUE, Color.WHITE, v -> showProgress()));

        root.addView(spacer(24));
        TextView mode = label(evaluator.recognitionModeLabel(), 12, Color.rgb(190, 201, 219), false, Gravity.CENTER);
        root.addView(mode);
        setScrollable(root, NAVY);
    }

    private void showLevels() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader("Select Level", "Choose your American English level", this::showHome);
        try {
            JSONArray levels = course.getLevels();
            for (int i = 0; i < levels.length(); i++) {
                JSONObject level = levels.getJSONObject(i);
                final JSONObject selectedLevel = level;
                root.addView(menuCard("🇺🇸", level.optString("title", "LEVEL " + (i + 1)),
                        level.optString("subtitle", ""), v -> {
                            currentLevel = selectedLevel;
                            showLevel1();
                        }));
            }
        } catch (JSONException e) {
            root.addView(label("Could not load levels.", 15, RED, false, Gravity.START));
        }
        root.addView(spacer(14));
        root.addView(actionButton("PRACTICE MENU", BLUE, Color.WHITE, v -> showMainMenu()));
        setScrollable(root, BG);
    }

    private void showMainMenu() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader("Training Menu", "Choose what you want to practice", this::showHome);
        root.addView(menuCard("🎧", "Listening Practice", "Listen to American English and repeat.", v -> { currentTopic = greetings; showDialogueSelection(false); }));
        root.addView(menuCard("🗣️", "Speaking Practice", "Record, evaluate and improve your answer.", v -> { currentTopic = greetings; showDialogueSelection(false); }));
        root.addView(menuCard("💬", "Conversation", "Practice a short real-life conversation.", v -> { currentTopic = greetings; showConversationIntro(); }));
        root.addView(menuCard("🇺🇸", "American Pronunciation", "Greeting sounds and pronunciation drills.", v -> { currentTopic = greetings; showPronunciation(); }));
        root.addView(menuCard("⚡", "American Fast Speech", "Slow → Normal → Fast training.", v -> { currentTopic = greetings; showFastSpeech(); }));
        root.addView(menuCard("📚", "Vocabulary", "Useful greetings and expressions.", v -> { currentTopic = greetings; showVocabulary(); }));
        root.addView(menuCard("📝", "Speaking Tests", "Level 1 – Greetings final test.", v -> { currentTopic = greetings; showFinalTestIntro(); }));
        root.addView(menuCard("📊", "My Progress", "Your local scores and practice history.", v -> showProgress()));
        root.addView(spacer(12));
        root.addView(actionButton("LEVEL 1 TOPICS", BLUE, Color.WHITE, v -> { try { currentLevel = course.getLevel1(); } catch (Exception ignored) {} showLevel1(); }));
        setScrollable(root, BG);
    }

    private void showLevel1() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader(currentLevel.optString("title", "LEVEL 1"), currentLevel.optString("subtitle", ""), this::showLevels);
        try {
            JSONArray topics = currentLevel.getJSONArray("topics");
            for (int i = 0; i < topics.length(); i++) {
                JSONObject t = topics.getJSONObject(i);
                boolean available = t.optBoolean("available", false);
                String title = (i + 1) + ". " + t.optString("title");
                if (available) {
                    final JSONObject selectedTopic = t;
                    root.addView(menuCard("🇺🇸", title, "Available now", v -> { currentTopic = selectedTopic; showGreetingsHub(); }));
                } else {
                    View card = menuCard("🔒", title, "Coming next • content-ready architecture", v -> toast("This topic is ready to be added in course_content.json."));
                    card.setAlpha(0.64f);
                    root.addView(card);
                }
            }
        } catch (JSONException e) {
            root.addView(label("Could not load topics.", 15, RED, false, Gravity.START));
        }
        setScrollable(root, BG);
    }

    private JSONObject topic() {
        return currentTopic != null ? currentTopic : greetings;
    }

    private String topicId() { return topic().optString("id", "greetings"); }
    private String topicTitle() { return topic().optString("title", "GREETINGS"); }

    private int completedDialoguesForCurrentTopic() {
        JSONArray ds = topic().optJSONArray("dialogues");
        if (ds == null) return 0;
        int n = 0;
        for (int i = 0; i < ds.length(); i++) {
            JSONObject d = ds.optJSONObject(i);
            if (d != null && progress.isDialogueCompleted(topicId(), d.optString("id"))) n++;
        }
        return n;
    }

    private void showGreetingsHub() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader(currentLevel.optString("title", "LEVEL 1") + " – " + topicTitle().toUpperCase(Locale.US), topic().optString("objective"), this::showLevel1);
        root.addView(sectionTitle("Practice path"));
        JSONArray moduleDialogues = topic().optJSONArray("dialogues");
        int dialogueCount = moduleDialogues == null ? 0 : moduleDialogues.length();
        root.addView(menuCard("📚", "1. Vocabulary", "Listen to key words and expressions.", v -> showVocabulary()));
        root.addView(menuCard("💬", "2. Dialogue Practice", dialogueCount + " practical dialogues.", v -> showDialogueSelection(false)));
        root.addView(menuCard("🎧", "3. Listening + Speaking", "LISTEN → RECORD → EVALUATE.", v -> { if (dialogueCount > 0) showDialogue(0, false); else toast("Add dialogues in course_content.json first."); }));
        root.addView(menuCard("🗣️", "4. Conversation Mode", "Talk with the app turn by turn.", v -> showConversationIntro()));
        root.addView(menuCard("📝", "5. Final Speaking Test", "Complete all speaking prompts.", v -> showFinalTestIntro()));
        setScrollable(root, BG);
    }

    private void showDialogueSelection(boolean testMode) {
        stopTransientAudio();
        LinearLayout root = pageWithHeader(testMode ? topicTitle() + " Speaking Test" : "Dialogue Practice",
                testMode ? "Complete each prompt without answer hints." : "Choose a dialogue and practice.", this::showGreetingsHub);
        JSONArray ds = topic().optJSONArray("dialogues");
        if (ds != null) {
            for (int i = 0; i < ds.length(); i++) {
                JSONObject d = ds.optJSONObject(i);
                final int index = i;
                String done = progress.isDialogueCompleted(topicId(), d.optString("id")) ? "Completed • practice again" : "Listen, record and evaluate";
                root.addView(menuCard("🗣️", d.optString("title"), done, v -> showDialogue(index, testMode)));
            }
        }
        setScrollable(root, BG);
    }

    private void showDialogue(int index, boolean testMode) {
        stopTransientAudio();
        JSONArray ds = topic().optJSONArray("dialogues");
        if (ds == null || index < 0 || index >= ds.length()) return;
        JSONObject d = ds.optJSONObject(index);
        LinearLayout root = pageWithHeader(d.optString("title"), testMode ? "FINAL TEST" : currentLevel.optString("title", "LEVEL 1") + " – " + topicTitle().toUpperCase(Locale.US), () -> {
            if (testMode) showFinalTestIntro(); else showDialogueSelection(false);
        });

        TextView step = pill((index + 1) + " / " + ds.length(), BLUE);
        root.addView(step);
        root.addView(spacer(12));
        root.addView(sectionTitle("APP SAYS"));
        TextView prompt = label(d.optString("prompt"), 25, NAVY, true, Gravity.START);
        prompt.setPadding(dp(18), dp(18), dp(18), dp(18));
        prompt.setBackground(round(Color.WHITE, 18, Color.rgb(220, 225, 232), 1));
        root.addView(prompt, fullWidth());

        root.addView(spacer(14));
        LinearLayout listenRow = horizontal();
        Button listen = smallButton("🎧 LISTEN", BLUE, Color.WHITE);
        Button replay = smallButton("🔁 REPLAY", Color.rgb(70, 86, 112), Color.WHITE);
        listenRow.addView(listen, weighted());
        listenRow.addView(spacerH(8));
        listenRow.addView(replay, weighted());
        root.addView(listenRow, fullWidth());

        if (!testMode) {
            root.addView(spacer(16));
            root.addView(sectionTitle("ACCEPTABLE ANSWERS"));
            JSONArray accepted = d.optJSONArray("acceptedAnswers");
            if (accepted != null) {
                for (int i = 0; i < accepted.length(); i++) {
                    root.addView(label("• " + accepted.optString(i), 15, TEXT, false, Gravity.START));
                }
            }
        }

        root.addView(spacer(18));
        root.addView(sectionTitle("YOUR TURN"));
        TextView status = label("Tap RECORD, speak naturally, then tap STOP.", 14, MUTED, false, Gravity.START);
        root.addView(status);

        LinearLayout recordRow = horizontal();
        Button record = smallButton("🎙️ RECORD", RED, Color.WHITE);
        Button playMine = smallButton("▶ PLAY MY ANSWER", Color.rgb(70, 86, 112), Color.WHITE);
        recordRow.addView(record, weighted());
        recordRow.addView(spacerH(8));
        recordRow.addView(playMine, weighted());
        root.addView(spacer(8));
        root.addView(recordRow, fullWidth());

        Button evaluateBtn = actionButton("✅ EVALUATE", GREEN, Color.WHITE, null);
        root.addView(spacer(10));
        root.addView(evaluateBtn);

        LinearLayout resultHost = vertical(Color.TRANSPARENT, 0);
        root.addView(spacer(16));
        root.addView(resultHost, fullWidth());

        View.OnClickListener playPrompt = v -> {
            try {
                modelAudio.play(d.optString("prompt"), d.optString("audioAsset"), 0.92f);
                progress.recordListen();
                status.setText("Listening to the American English model…");
            } catch (IOException e) {
                status.setText(e.getMessage());
            }
        };
        listen.setOnClickListener(playPrompt);
        replay.setOnClickListener(playPrompt);

        record.setOnClickListener(v -> withMicPermission(() -> {
            try {
                if (!recorder.isRecording()) {
                    recorder.start(this);
                    record.setText("⏹ STOP");
                    record.setBackground(round(Color.rgb(139, 30, 36), 12, Color.TRANSPARENT, 0));
                    status.setText("Recording… Speak your answer now.");
                    resultHost.removeAllViews();
                } else {
                    AudioRecorder.Recording r = recorder.stop();
                    record.setText("🎙️ RECORD");
                    record.setBackground(round(RED, 12, Color.TRANSPARENT, 0));
                    status.setText(String.format(Locale.US, "Recorded %.1f seconds. You can play or evaluate it.", r == null ? 0 : r.durationSeconds));
                }
            } catch (Exception e) {
                status.setText("Recording error: " + e.getMessage());
            }
        }));

        playMine.setOnClickListener(v -> {
            try {
                if (recorder.isRecording()) recorder.stop();
                recorder.playLast();
                status.setText("Playing your answer…");
            } catch (Exception e) {
                status.setText("Record an answer first.");
            }
        });

        evaluateBtn.setOnClickListener(v -> withMicPermission(() -> {
            try {
                if (recorder.isRecording()) {
                    recorder.stop();
                    record.setText("🎙️ RECORD");
                }
            } catch (IOException ignored) {}
            AudioRecorder.Recording r = recorder.currentRecording();
            if (r == null) {
                status.setText("Record an answer first.");
                return;
            }
            evaluateBtn.setEnabled(false);
            evaluateBtn.setText("ANALYZING…");
            evaluator.evaluate(r, d.optJSONArray("acceptedAnswers"), d.optBoolean("openResponse", false), d.optInt("minWords", 2),
                    new SpeechEvaluationEngine.Callback() {
                        @Override public void onStatus(String text) { status.setText(text); }
                        @Override public void onSuccess(SpeechScore score) {
                            evaluateBtn.setEnabled(true);
                            evaluateBtn.setText("✅ EVALUATE AGAIN");
                            progress.recordPractice(score);
                            if (!testMode) progress.markDialogueCompleted(topicId(), d.optString("id"));
                            showScoreInHost(resultHost, score, () -> {
                                if (testMode) {
                                    testScores.add(score);
                                    if (index + 1 < ds.length()) showDialogue(index + 1, true);
                                    else showFinalResult(testScores);
                                } else if (index + 1 < ds.length()) {
                                    showDialogue(index + 1, false);
                                } else {
                                    showGreetingsHub();
                                }
                            }, index + 1 < ds.length() ? "➡ NEXT QUESTION" : (testMode ? "🏆 FINAL RESULT" : "✓ FINISH"));
                        }
                        @Override public void onError(String message) {
                            evaluateBtn.setEnabled(true);
                            evaluateBtn.setText("✅ EVALUATE");
                            status.setText(message);
                        }
                    });
        }));

        setScrollable(root, BG);
    }

    private void showScoreInHost(LinearLayout host, SpeechScore score, Runnable next, String nextLabel) {
        host.removeAllViews();
        LinearLayout card = vertical(Color.WHITE, 16);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(Color.WHITE, 18, Color.rgb(220, 225, 232), 1));
        card.addView(label("YOUR SCORE", 18, NAVY, true, Gravity.START));
        card.addView(metric("PRONUNCIATION", score.pronunciation));
        card.addView(metric("WORD ACCURACY", score.wordAccuracy));
        card.addView(metric("FLUENCY", score.fluency));
        card.addView(metric("SPEAKING", score.speaking));
        card.addView(metric("OVERALL", score.overall));
        card.addView(spacer(10));
        card.addView(label(score.feedback, 15, score.overall >= 75 ? GREEN : RED, true, Gravity.START));
        card.addView(spacer(10));
        card.addView(label("Recognized: “" + score.transcript + "”", 13, TEXT, false, Gravity.START));
        if (score.matchedAnswer != null && !score.matchedAnswer.isEmpty()) {
            card.addView(label("Closest accepted answer: “" + score.matchedAnswer + "”", 13, MUTED, false, Gravity.START));
        }
        card.addView(spacer(10));
        card.addView(label("Prototype note: Pronunciation is an estimate based on speech-recognition confidence + word match. It is not phoneme-level pronunciation analysis.", 11, MUTED, false, Gravity.START));
        card.addView(spacer(14));
        card.addView(actionButton(nextLabel, BLUE, Color.WHITE, v -> next.run()));
        host.addView(card, fullWidth());
    }

    private void showConversationIntro() {
        LinearLayout root = pageWithHeader("💬 CONVERSATION", "The app speaks. You answer. Continue naturally.", this::showMainMenu);
        root.addView(cardText("Conversation – " + topicTitle(),
                "APP: Hi! How are you?\nSTUDENT: 🎙️ answer\n\nAPP: Nice! Where are you from?\nSTUDENT: 🎙️ answer\n\nAPP: Nice to meet you!\nSTUDENT: 🎙️ answer"));
        root.addView(spacer(18));
        root.addView(actionButton("START CONVERSATION", GREEN, Color.WHITE, v -> {
            conversationScores.clear();
            showConversationTurn(0);
        }));
        setScrollable(root, BG);
    }

    private void showConversationTurn(int index) {
        stopTransientAudio();
        JSONArray turns = topic().optJSONArray("conversation");
        if (turns == null || index >= turns.length()) {
            showConversationResult();
            return;
        }
        JSONObject turn = turns.optJSONObject(index);
        LinearLayout root = pageWithHeader("Conversation", "Turn " + (index + 1) + " of " + turns.length(), this::showConversationIntro);
        root.addView(sectionTitle("APP"));
        root.addView(cardText("", turn.optString("prompt")));
        root.addView(spacer(12));
        TextView status = label("Listen first, then record your answer.", 14, MUTED, false, Gravity.START);
        root.addView(status);
        root.addView(spacer(8));
        Button listen = actionButton("🎧 LISTEN", BLUE, Color.WHITE, v -> {
            try { modelAudio.play(turn.optString("prompt"), "", 0.92f); progress.recordListen(); }
            catch (IOException e) { status.setText(e.getMessage()); }
        });
        root.addView(listen);
        root.addView(spacer(10));
        Button rec = actionButton("🎙️ RECORD", RED, Color.WHITE, null);
        root.addView(rec);
        root.addView(spacer(10));
        Button eval = actionButton("✅ EVALUATE & CONTINUE", GREEN, Color.WHITE, null);
        root.addView(eval);
        LinearLayout host = vertical(Color.TRANSPARENT, 0);
        root.addView(spacer(14));
        root.addView(host);

        rec.setOnClickListener(v -> withMicPermission(() -> {
            try {
                if (!recorder.isRecording()) {
                    recorder.start(this); rec.setText("⏹ STOP"); status.setText("Recording…");
                } else {
                    recorder.stop(); rec.setText("🎙️ RECORD"); status.setText("Answer recorded.");
                }
            } catch (Exception e) { status.setText("Recording error: " + e.getMessage()); }
        }));

        eval.setOnClickListener(v -> withMicPermission(() -> {
            try { if (recorder.isRecording()) recorder.stop(); } catch (Exception ignored) {}
            AudioRecorder.Recording r = recorder.currentRecording();
            if (r == null) { status.setText("Record an answer first."); return; }
            eval.setEnabled(false);
            eval.setText("ANALYZING…");
            evaluator.evaluate(r, turn.optJSONArray("acceptedAnswers"), turn.optBoolean("openResponse", false), turn.optInt("minWords", 2), new SpeechEvaluationEngine.Callback() {
                @Override public void onStatus(String text) { status.setText(text); }
                @Override public void onSuccess(SpeechScore score) {
                    progress.recordPractice(score);
                    conversationScores.add(score);
                    eval.setEnabled(true);
                    showScoreInHost(host, score, () -> showConversationTurn(index + 1), index + 1 < turns.length() ? "➡ CONTINUE" : "🏆 CONVERSATION RESULT");
                }
                @Override public void onError(String message) { eval.setEnabled(true); eval.setText("✅ EVALUATE & CONTINUE"); status.setText(message); }
            });
        }));
        setScrollable(root, BG);
    }

    private void showConversationResult() {
        SpeechScore avg = average(conversationScores);
        LinearLayout root = pageWithHeader("CONVERSATION RESULT", currentLevel.optString("title", "LEVEL 1") + " – " + topicTitle().toUpperCase(Locale.US), this::showConversationIntro);
        root.addView(scoreSummary(avg));
        root.addView(spacer(16));
        root.addView(actionButton("🔁 RETAKE CONVERSATION", BLUE, Color.WHITE, v -> {
            conversationScores.clear(); showConversationTurn(0);
        }));
        root.addView(spacer(10));
        root.addView(actionButton("BACK TO TOPIC", Color.rgb(70, 86, 112), Color.WHITE, v -> showGreetingsHub()));
        setScrollable(root, BG);
    }

    private void showFinalTestIntro() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader(currentLevel.optString("title", "LEVEL 1") + " – " + topicTitle().toUpperCase(Locale.US) + " SPEAKING TEST", "Complete all prompts • one final result", this::showHome);
        root.addView(cardText("Test rules",
                "1. Listen to the model.\n2. Record your answer.\n3. Evaluate your speech.\n4. Continue through all 5 prompts.\n5. Receive a final score and feedback."));
        root.addView(spacer(14));
        root.addView(label("Accepted-answer hints are hidden during the test.", 13, MUTED, false, Gravity.START));
        root.addView(spacer(20));
        root.addView(actionButton("START SPEAKING TEST", RED, Color.WHITE, v -> {
            testScores.clear(); showDialogue(0, true);
        }));
        setScrollable(root, BG);
    }

    private void showFinalResult(List<SpeechScore> scores) {
        SpeechScore avg = average(scores);
        progress.markTestCompleted(topicId(), avg.overall);
        LinearLayout root = pageWithHeader("YOUR RESULT", currentLevel.optString("title", "LEVEL 1") + " – " + topicTitle().toUpperCase(Locale.US), this::showHome);
        root.addView(scoreSummary(avg));
        root.addView(spacer(12));
        root.addView(cardText("Feedback", avg.feedback + " Keep practicing your fluency and American pronunciation."));
        root.addView(spacer(16));
        root.addView(actionButton("🔁 RETAKE TEST", RED, Color.WHITE, v -> { testScores.clear(); showDialogue(0, true); }));
        root.addView(spacer(10));
        root.addView(actionButton("➡ NEXT LESSON", BLUE, Color.WHITE, v -> new AlertDialog.Builder(this)
                .setTitle("Next lesson")
                .setMessage("Introducing Yourself is prepared in the course structure and can be added next in course_content.json.")
                .setPositiveButton("OK", null).show()));
        setScrollable(root, BG);
    }

    private LinearLayout scoreSummary(SpeechScore s) {
        LinearLayout c = vertical(Color.WHITE, 12);
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(round(Color.WHITE, 18, Color.rgb(220, 225, 232), 1));
        c.addView(metric("Pronunciation", s.pronunciation));
        c.addView(metric("Word Accuracy", s.wordAccuracy));
        c.addView(metric("Fluency", s.fluency));
        c.addView(metric("Speaking", s.speaking));
        c.addView(metric("Overall Score", s.overall));
        c.addView(spacer(8));
        c.addView(label("Pronunciation score = prototype estimate, not phoneme-level analysis.", 11, MUTED, false, Gravity.START));
        return c;
    }

    private void showVocabulary() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader("📚 VOCABULARY", topicTitle() + " – listen and repeat", this::showMainMenu);
        JSONArray vocab = topic().optJSONArray("vocabulary");
        if (vocab != null) {
            for (int i = 0; i < vocab.length(); i++) {
                JSONObject item = vocab.optJSONObject(i);
                LinearLayout c = vertical(Color.WHITE, 8);
                c.setPadding(dp(16), dp(16), dp(16), dp(16));
                c.setBackground(round(Color.WHITE, 16, Color.rgb(224, 228, 235), 1));
                TextView word = label(item.optString("word"), 19, NAVY, true, Gravity.START);
                c.addView(word);
                c.addView(label(item.optString("meaning"), 13, MUTED, false, Gravity.START));
                c.addView(label(item.optString("example"), 14, TEXT, false, Gravity.START));
                c.addView(spacer(8));
                Button b = smallButton("🎧 LISTEN", BLUE, Color.WHITE);
                b.setOnClickListener(v -> {
                    try { modelAudio.play(item.optString("word"), "", 0.90f); progress.recordListen(); }
                    catch (IOException e) { toast(e.getMessage()); }
                });
                c.addView(b);
                root.addView(c, marginBottom(10));
            }
        }
        setScrollable(root, BG);
    }

    private void showFastSpeech() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader("⚡ AMERICAN FAST SPEECH", "Slow → Normal → Fast", this::showMainMenu);
        root.addView(label("Prototype drills for " + topicTitle() + ". Focus on rhythm and connected speech, not speed alone.", 14, MUTED, false, Gravity.START));
        root.addView(spacer(12));
        JSONArray items = topic().optJSONArray("fastSpeech");
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                LinearLayout c = vertical(Color.WHITE, 8);
                c.setPadding(dp(16), dp(16), dp(16), dp(16));
                c.setBackground(round(Color.WHITE, 16, Color.rgb(224, 228, 235), 1));
                c.addView(label(item.optString("text"), 21, NAVY, true, Gravity.START));
                c.addView(label(item.optString("tip"), 13, MUTED, false, Gravity.START));
                c.addView(spacer(10));
                LinearLayout row = horizontal();
                Button slow = smallButton("0.75×", Color.rgb(70, 86, 112), Color.WHITE);
                Button normal = smallButton("1×", BLUE, Color.WHITE);
                Button fast = smallButton("1.15×", RED, Color.WHITE);
                row.addView(slow, weighted()); row.addView(spacerH(6)); row.addView(normal, weighted()); row.addView(spacerH(6)); row.addView(fast, weighted());
                slow.setOnClickListener(v -> speakRate(item.optString("text"), 0.75f));
                normal.setOnClickListener(v -> speakRate(item.optString("text"), 0.95f));
                fast.setOnClickListener(v -> speakRate(item.optString("text"), 1.15f));
                c.addView(row);
                root.addView(c, marginBottom(10));
            }
        }
        setScrollable(root, BG);
    }

    private void showPronunciation() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader("🇺🇸 AMERICAN PRONUNCIATION", "Greetings prototype drills", this::showMainMenu);
        root.addView(cardText("1. H sound", "Hi! • How are you?\nKeep the /h/ light and airy."));
        root.addView(pronunciationListen("Hi! How are you?"));
        root.addView(spacer(10));
        root.addView(cardText("2. American R", "great • morning\nDo not roll the R."));
        root.addView(pronunciationListen("I'm great. Good morning!"));
        root.addView(spacer(10));
        root.addView(cardText("3. Natural rhythm", "Nice to meet you.\nDo not pronounce every word with equal stress."));
        root.addView(pronunciationListen("Nice to meet you."));
        root.addView(spacer(14));
        root.addView(label("Full modules for American R, Flap T, TH, V/W, vowels, stress, intonation, rhythm, linking, connected speech, reduced forms and contractions can be added as separate topics without changing the app logic.", 13, MUTED, false, Gravity.START));
        setScrollable(root, BG);
    }

    private View pronunciationListen(String text) {
        Button b = actionButton("🎧 LISTEN & REPEAT", BLUE, Color.WHITE, v -> speakRate(text, 0.90f));
        return b;
    }

    private void showProgress() {
        stopTransientAudio();
        LinearLayout root = pageWithHeader("📊 MY PROGRESS", "Saved locally on this phone", this::showHome);
        root.addView(cardText("LEVEL 1", "Current prototype: Greetings"));
        root.addView(spacer(12));
        LinearLayout c = vertical(Color.WHITE, 10);
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(round(Color.WHITE, 18, Color.rgb(220, 225, 232), 1));
        currentTopic = greetings;
        c.addView(progressLine("Greetings completed", completedDialoguesForCurrentTopic() + " / 5 dialogues"));
        c.addView(progressLine("Speaking Score", progress.avgSpeaking() + "%"));
        c.addView(progressLine("Pronunciation Score", progress.avgPronunciation() + "%"));
        c.addView(progressLine("Listening Score", progress.listeningScore() + "%"));
        c.addView(progressLine("Fluency Score", progress.avgFluency() + "%"));
        c.addView(progressLine("Average Score", progress.avgOverall() + "%"));
        c.addView(progressLine("Number of practices", String.valueOf(progress.practiceCount())));
        c.addView(progressLine("Listening plays", String.valueOf(progress.listenCount())));
        if (progress.testDone("greetings")) c.addView(progressLine("Greetings test", progress.testScore("greetings") + "%"));
        root.addView(c);
        root.addView(spacer(14));
        root.addView(label("Progress is stored with SharedPreferences. No account or server is used in this prototype.", 12, MUTED, false, Gravity.START));
        root.addView(spacer(16));
        root.addView(actionButton("RESET LOCAL PROGRESS", Color.rgb(92, 102, 119), Color.WHITE, v -> new AlertDialog.Builder(this)
                .setTitle("Reset progress?")
                .setMessage("This will delete local practice scores on this phone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (d, w) -> { progress.reset(); showProgress(); })
                .show()));
        setScrollable(root, BG);
    }

    private void speakRate(String text, float rate) {
        try { modelAudio.play(text, "", rate); progress.recordListen(); }
        catch (IOException e) { toast(e.getMessage()); }
    }

    private SpeechScore average(List<SpeechScore> scores) {
        if (scores == null || scores.isEmpty()) return new SpeechScore(0,0,0,0,0,"","","No result yet.");
        int p=0,w=0,f=0,s=0,o=0;
        for (SpeechScore x: scores) { p+=x.pronunciation; w+=x.wordAccuracy; f+=x.fluency; s+=x.speaking; o+=x.overall; }
        int n=scores.size();
        int overall=Math.round((float)o/n);
        String feedback = overall >= 90 ? "Excellent! Keep practicing." : overall >= 80 ? "Good job! Keep your rhythm natural." : overall >= 70 ? "Good job! Keep practicing your fluency." : "Keep practicing. Repeat the difficult phrases slowly, then naturally.";
        return new SpeechScore(Math.round((float)p/n),Math.round((float)w/n),Math.round((float)f/n),Math.round((float)s/n),overall,"","",feedback);
    }

    private void withMicPermission(Runnable action) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action.run();
        } else {
            afterPermissionAction = action;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
    }

    private void stopTransientAudio() {
        if (recorder.isRecording()) {
            try { recorder.stop(); } catch (Exception ignored) {}
        }
        recorder.stopPlayback();
        if (modelAudio != null) modelAudio.stop();
        if (evaluator != null) evaluator.release();
    }

    private LinearLayout pageWithHeader(String title, String subtitle, Runnable back) {
        LinearLayout root = vertical(BG, 16);
        root.setPadding(dp(18), dp(14), dp(18), dp(28));
        LinearLayout bar = horizontal();
        Button backBtn = smallButton("←", NAVY, Color.WHITE);
        backBtn.setMinWidth(dp(52));
        backBtn.setOnClickListener(v -> back.run());
        bar.addView(backBtn, new LinearLayout.LayoutParams(dp(56), dp(48)));
        LinearLayout texts = vertical(Color.TRANSPARENT, 2);
        texts.setPadding(dp(12), 0, 0, 0);
        texts.addView(label(title, 22, NAVY, true, Gravity.START));
        if (subtitle != null && !subtitle.isEmpty()) texts.addView(label(subtitle, 13, MUTED, false, Gravity.START));
        bar.addView(texts, weighted());
        root.addView(bar, fullWidth());
        root.addView(spacer(16));
        return root;
    }

    private View menuCard(String icon, String title, String subtitle, View.OnClickListener click) {
        LinearLayout card = horizontal();
        card.setPadding(dp(16), dp(14), dp(14), dp(14));
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackground(round(Color.WHITE, 16, Color.rgb(225, 229, 235), 1));
        TextView ic = label(icon, 26, TEXT, false, Gravity.CENTER);
        card.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(48)));
        LinearLayout txt = vertical(Color.TRANSPARENT, 2);
        txt.setPadding(dp(8), 0, dp(6), 0);
        txt.addView(label(title, 17, NAVY, true, Gravity.START));
        txt.addView(label(subtitle, 13, MUTED, false, Gravity.START));
        card.addView(txt, weighted());
        card.addView(label("›", 28, BLUE, false, Gravity.CENTER), new LinearLayout.LayoutParams(dp(30), dp(48)));
        card.setOnClickListener(click);
        LinearLayout.LayoutParams p = fullWidth();
        p.setMargins(0,0,0,dp(10));
        card.setLayoutParams(p);
        return card;
    }

    private LinearLayout cardText(String title, String body) {
        LinearLayout c = vertical(Color.WHITE, 6);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(round(Color.WHITE, 16, Color.rgb(224, 228, 235), 1));
        if (title != null && !title.isEmpty()) c.addView(label(title, 17, NAVY, true, Gravity.START));
        c.addView(label(body, 15, TEXT, false, Gravity.START));
        return c;
    }

    private View metric(String name, int value) {
        LinearLayout row = horizontal();
        row.setPadding(0, dp(6), 0, dp(6));
        TextView l = label(name, 14, TEXT, false, Gravity.START);
        TextView r = label(value + "/100", 17, value >= 75 ? GREEN : (value >= 60 ? BLUE : RED), true, Gravity.END);
        row.addView(l, weighted());
        row.addView(r, new LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private View progressLine(String name, String value) {
        LinearLayout row = horizontal();
        row.setPadding(0, dp(7), 0, dp(7));
        row.addView(label(name, 14, TEXT, false, Gravity.START), weighted());
        row.addView(label(value, 15, NAVY, true, Gravity.END));
        return row;
    }

    private TextView sectionTitle(String s) {
        TextView t = label(s, 13, BLUE, true, Gravity.START);
        t.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams p = fullWidth();
        p.setMargins(0,0,0,dp(8));
        t.setLayoutParams(p);
        return t;
    }

    private TextView pill(String s, int color) {
        TextView t = label(s, 12, color, true, Gravity.CENTER);
        t.setPadding(dp(10), dp(5), dp(10), dp(5));
        t.setBackground(round(Color.rgb(234, 240, 249), 30, Color.TRANSPARENT, 0));
        return t;
    }

    private Button actionButton(String text, int bg, int fg, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        b.setBackground(round(bg, 14, Color.TRANSPARENT, 0));
        b.setMinHeight(dp(52));
        if (click != null) b.setOnClickListener(click);
        b.setLayoutParams(fullWidth());
        return b;
    }

    private Button smallButton(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setBackground(round(bg, 12, Color.TRANSPARENT, 0));
        b.setMinHeight(dp(46));
        return b;
    }

    private TextView label(String text, int sp, int color, boolean bold, int gravity) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(gravity);
        t.setLineSpacing(0, 1.12f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout vertical(int color, int gap) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(color);
        if (gap > 0) l.setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private View spacer(int h) {
        Space s = new Space(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return s;
    }

    private View spacerH(int w) {
        Space s = new Space(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1));
        return s;
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams marginBottom(int dpVal) {
        LinearLayout.LayoutParams p = fullWidth();
        p.setMargins(0,0,0,dp(dpVal));
        return p;
    }

    private GradientDrawable round(int fill, int radiusDp, int strokeColor, int strokeWidthDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeWidthDp > 0) d.setStroke(dp(strokeWidthDp), strokeColor);
        return d;
    }

    private void setScrollable(LinearLayout content, int background) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(background);
        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void showFatal(String message) {
        TextView t = label(message, 16, RED, false, Gravity.CENTER);
        t.setPadding(dp(24),dp(24),dp(24),dp(24));
        setContentView(t);
    }
}
